<?php
$idalmarhum = $_POST['id_almarhum'];
$idrumahduka = $_POST['rumahduka'];
$nama = $_POST['nama_almarhum'];
$image = $_FILES['foto']['tmp_name'];
$imgContent = addslashes(file_get_contents($image));
$lahir = $_POST['tanggal_lahir'];
$kematian = $_POST['tanggal_kematian'];
$alamat = $_POST['alamat'];
$kontak = $_POST['kontak_keluarga'];
$upacara = $_POST['upacara_kematian'];
$sts = $_POST['status'];


include '../koneksi.php';
if ($koneksi->connect_error) {
    echo "$koneksi->connect_error";
    die("Connection Failed : " . $koneksi->connect_error);
} else {
    $stmt = $koneksi->prepare("INSERT into tb_almarhum VALUES ('$idalmarhum','$idrumahduka','$nama','$imgContent','$lahir','$kematian','$alamat','$kontak','$upacara','$sts')");
    $execval = $stmt->execute();
    echo $execval;
    $stmt->close();
    $conn->close();
?>
    <script type="text/javascript">
        alert("Data Berhasil Disimpan");
        window.location.href = "Kabar-duka.php";
    </script>
<?php
}
?>