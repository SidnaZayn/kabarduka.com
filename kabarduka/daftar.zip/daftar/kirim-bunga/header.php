
    <!-- ======= Header ======= -->
    <header id="header">
        <div class="container d-flex">

            <div class="logo mr-auto">
                <h1 class="text-light"><a href="../../index.php"><span>Kabarduka.com</span></a></h1>
                <!-- Uncomment below if you prefer to use an image logo -->
                <!--<a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid" height="20px" width="40px"></a>-->
            </div>

            <nav class="nav-menu d-none d-lg-block">
                <ul>
                    <li><a href="../../index.php">Home</a></li>
                    <li><a href="../../About-us.php">About Us</a></li>
                    <li><a href="kirim-bunga.php">Kirim Bunga</a></li>
                    <li><a href="../../Rumah-duka.php">Rumah Duka</a></li>
                    <li><a href="../../Kerja-sama.php">Kerja Sama</a></li>
                    <li><a href="../../FAQ.php">FAQ</a></li>
                    <li><a href="../../Contact.php">Contact</a></li>

                </ul>
            </nav><!-- .nav-menu -->

        </div>
    </header><!-- End Header -->
